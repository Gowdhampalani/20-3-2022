package com.example.day2demo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private CheckBox chkIos, chkAndroid, chkWindows;
    private Button btnDisplay;

    RadioGroup radioGroup;
    RadioButton radioButton;;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addListenerOnChkIos();
        addListenerOnButton();

        radioGroup = (RadioGroup) findViewById(R.id.radioios);
        radioButton = (RadioButton) findViewById(R.id.radioios1);
        btnDisplay = (Button) findViewById(R.id.btnDisplay);

    }


    private void addListenerOnButton() {

        chkIos = (CheckBox) findViewById(R.id.chkIos);
        chkAndroid = (CheckBox) findViewById(R.id.chkAndroid);
        chkWindows = (CheckBox) findViewById(R.id.chkWindows);
        btnDisplay = (Button) findViewById(R.id.btnDisplay);



        btnDisplay.setOnClickListener(new View.OnClickListener() {

            //Run when button is clicked
            @Override
            public void onClick(View v) {

                StringBuffer result = new StringBuffer();
                result.append("IPhone check : ").append(chkIos.isChecked());
                // get selected radio button from radioGroup
                int selectedId = radioGroup.getCheckedRadioButtonId();

                // find the radiobutton by returned id
                radioButton = (RadioButton) findViewById(selectedId);
                result.append("\nAndroid check : ").append(chkAndroid.isChecked());
                // get selected radio button from radioGroup
                int selectedanId = radioGroup.getCheckedRadioButtonId();

                // find the radiobutton by returned id
                radioButton = (RadioButton) findViewById(selectedanId);
                result.append("\nWindows Mobile check :").append(chkWindows.isChecked());
                // get selected radio button from radioGroup
                int selectedwinId = radioGroup.getCheckedRadioButtonId();

                // find the radiobutton by returned id
                radioButton = (RadioButton) findViewById(selectedwinId);

                Toast.makeText(MainActivity.this,
                        "Devices updated Successfuly", Toast.LENGTH_LONG).show();
            }
        });

    }

    private void addListenerOnChkIos() {

        chkIos = (CheckBox) findViewById(R.id.chkIos);

        chkIos.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //is chkIos checked?
                if (((CheckBox) v).isChecked()) {

                }

            }
        });

    }

}